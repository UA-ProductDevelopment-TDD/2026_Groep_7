// Bittle wifi camera: firmware for a Seeed XIAO ESP32S3 Sense, alone or stacked on a Grove Vision AI V2.
//
// The XIAO joins your wifi network and makes the camera reachable for the Bittle Platform:
//   * tcp port 3333: the Grove Vision AI V2's own SSCMA AT protocol (the same JSON lines it speaks over USB, with
//     its AI model's boxes and the JPEG of every frame). The XIAO passes the bytes through unchanged over its UART
//     pins (D6 = TX, D7 = RX, 921600 baud), so the platform reads the board exactly as it does over USB.
//     Without a Vision AI V2 on the pins the XIAO answers the same commands itself with its own Sense camera
//     (frames only, no AI), so the platform still gets a picture.
//   * http port 80: a small status page, /status (JSON), /frame.jpg (the Sense camera) and a button to forget the wifi.
//   * mDNS name bittle-camera.local.
//
// First start, or after "forget wifi" (or holding BOOT 5 s): the XIAO opens the hotspot "Bittle-Camera".
// Join it with a phone or laptop; the setup page opens (or browse to 192.168.4.1), pick your 2.4 GHz network and type
// its password there. The XIAO keeps it and connects by itself from then on. Libraries: WiFiManager (tzapu).
#include <WiFi.h>
#include <WiFiManager.h>
#include <ESPmDNS.h>
#include <esp_http_server.h>
#include <esp_camera.h>
#include <mbedtls/base64.h>

static const char *NAME = "bittle-camera";
static const char *HOTSPOT = "Bittle-Camera";
static const char *VERSION = "bittle-camera 1.0";
static const uint16_t BRIDGE_PORT = 3333;
static const uint32_t VISION_BAUD = 921600;
static const int VISION_RX = 44, VISION_TX = 43;  // D7, D6 on the XIAO header
static const int LED = 21;                        // the XIAO's orange user LED, on when low
static const int BOOT_BUTTON = 0;
static const uint32_t FORGET_HOLD_MS = 5000;

// The XIAO ESP32S3 Sense camera connector.
static const int CAM_XCLK = 10, CAM_SIOD = 40, CAM_SIOC = 39, CAM_VSYNC = 38, CAM_HREF = 47, CAM_PCLK = 13;
static const int CAM_D[8] = {15, 17, 18, 16, 14, 12, 11, 48};  // Y2 .. Y9

HardwareSerial vision(1);
WiFiServer bridge(BRIDGE_PORT);
httpd_handle_t web = nullptr;

volatile bool visionFound = false;   // a Grove Vision AI V2 answered on the UART pins
volatile bool ownCamera = false;     // the Sense camera started
volatile bool clientConnected = false;
String clientAddress;
uint32_t buttonDown = 0;

// ---- Grove Vision AI V2 ----

// Ask the board for its name: any answer means it is there.
bool probeVision() {
  vision.write("\rAT+BREAK\r");
  delay(100);
  while (vision.available()) vision.read();
  vision.write("AT+NAME?\r");
  String seen;
  uint32_t start = millis();
  while (millis() - start < 1500) {
    while (vision.available()) {
      char c = vision.read();
      if (seen.length() < 512) seen += c;
    }
    if (seen.indexOf("NAME?") >= 0) return true;
    delay(5);
  }
  return false;
}

// Pass every byte through in both directions while the platform is connected.
void runBridge(WiFiClient &client) {
  static uint8_t fromVision[4096], fromClient[512];
  while (client.connected()) {
    bool idle = true;
    int n = vision.available();
    if (n > 0) {
      n = vision.read(fromVision, min(n, (int)sizeof(fromVision)));
      client.write(fromVision, n);
      idle = false;
    }
    int m = client.available();
    if (m > 0) {
      m = client.read(fromClient, min(m, (int)sizeof(fromClient)));
      vision.write(fromClient, m);
      idle = false;
    }
    checkButton();
    if (idle) delay(1);
  }
  vision.write("\rAT+BREAK\r");  // stop the stream the platform started
}

// ---- The XIAO's own Sense camera ----

bool startOwnCamera() {
  camera_config_t config = {};
  config.ledc_channel = LEDC_CHANNEL_0;
  config.ledc_timer = LEDC_TIMER_0;
  config.pin_d0 = CAM_D[0]; config.pin_d1 = CAM_D[1]; config.pin_d2 = CAM_D[2]; config.pin_d3 = CAM_D[3];
  config.pin_d4 = CAM_D[4]; config.pin_d5 = CAM_D[5]; config.pin_d6 = CAM_D[6]; config.pin_d7 = CAM_D[7];
  config.pin_xclk = CAM_XCLK;
  config.pin_pclk = CAM_PCLK;
  config.pin_vsync = CAM_VSYNC;
  config.pin_href = CAM_HREF;
  config.pin_sccb_sda = CAM_SIOD;
  config.pin_sccb_scl = CAM_SIOC;
  config.pin_pwdn = -1;
  config.pin_reset = -1;
  config.xclk_freq_hz = 20000000;
  config.pixel_format = PIXFORMAT_JPEG;
  config.frame_size = FRAMESIZE_240X240;
  config.jpeg_quality = 12;
  config.fb_count = 2;
  config.fb_location = psramFound() ? CAMERA_FB_IN_PSRAM : CAMERA_FB_IN_DRAM;
  config.grab_mode = CAMERA_GRAB_LATEST;
  if (!psramFound()) config.fb_count = 1;
  return esp_camera_init(&config) == ESP_OK;
}

// The platform's image sizes (AT+SENSOR option 0, 1, 2) for the Sense camera.
framesize_t frameSizeFor(int option) {
  if (option == 1) return FRAMESIZE_HVGA;  // 480 x 320
  if (option == 2) return FRAMESIZE_VGA;   // 640 x 480
  return FRAMESIZE_240X240;
}

void reply(WiFiClient &client, const String &name, int code, const String &data) {
  client.print("{\"type\": 0, \"name\": \"" + name + "\", \"code\": " + String(code) + ", \"data\": " + data + "}\r\n");
}

// One frame as an SSCMA SAMPLE event, the JPEG base64 encoded piece by piece.
bool sendFrame(WiFiClient &client, uint32_t count) {
  camera_fb_t *frame = esp_camera_fb_get();
  if (!frame) return false;
  client.print("{\"type\": 1, \"name\": \"SAMPLE\", \"code\": 0, \"data\": {\"count\": " + String(count) +
               ", \"resolution\": [" + String(frame->width) + ", " + String(frame->height) + "], \"image\": \"");
  static unsigned char encoded[4100];
  for (size_t at = 0; at < frame->len && client.connected(); at += 3072) {
    size_t take = min((size_t)3072, frame->len - at), written = 0;
    mbedtls_base64_encode(encoded, sizeof(encoded), &written, frame->buf + at, take);
    client.write(encoded, written);
  }
  client.print("\"}}\r\n");
  esp_camera_fb_return(frame);
  return true;
}

// Answer the AT commands the platform uses, with the Sense camera instead of a Vision AI V2.
void runOwnCamera(WiFiClient &client) {
  String line;
  bool streaming = false;
  uint32_t count = 0;
  while (client.connected()) {
    while (client.available()) {
      char c = client.read();
      if (c != '\r' && c != '\n') {
        if (line.length() < 128) line += c;
        continue;
      }
      line.trim();
      if (!line.startsWith("AT+")) {
        line = "";
        continue;
      }
      String command = line.substring(3);
      String name = command.substring(0, command.indexOf('=') < 0 ? command.length() : command.indexOf('='));
      line = "";
      if (name == "BREAK") {
        streaming = false;
        reply(client, name, 0, "{}");
      } else if (name == "NAME?") {
        reply(client, name, 0, "\"XIAO ESP32S3 Sense camera\"");
      } else if (name == "VER?") {
        reply(client, name, 0, String("{\"software\": \"") + VERSION + "\", \"hardware\": \"xiao-esp32s3\"}");
      } else if (name == "INFO?") {
        reply(client, name, 0, "{\"crc16_maxim\": 0, \"info\": \"\"}");  // no AI model on the XIAO
      } else if (name == "SENSOR") {
        int option = command.substring(command.lastIndexOf(',') + 1).toInt();
        sensor_t *sensor = ownCamera ? esp_camera_sensor_get() : nullptr;
        bool ok = sensor && sensor->set_framesize(sensor, frameSizeFor(option)) == 0;
        reply(client, name, ok ? 0 : 4, "{}");
      } else if (name == "SAMPLE") {
        streaming = ownCamera;
        reply(client, name, ownCamera ? 0 : 4, "{}");
      } else {
        reply(client, name, 3, "{}");  // not supported here (AT+INVOKE needs the Vision AI V2)
      }
    }
    if (streaming) {
      if (!sendFrame(client, count++)) delay(20);
    } else {
      delay(5);
    }
    checkButton();
  }
}

// ---- Web page ----

String statusJson() {
  String mode = visionFound ? "vision-ai" : ownCamera ? "xiao-camera" : "none";
  return "{\"name\": \"" + String(NAME) + "\", \"version\": \"" + VERSION + "\", \"mode\": \"" + mode +
         "\", \"ip\": \"" + WiFi.localIP().toString() + "\", \"ssid\": \"" + WiFi.SSID() +
         "\", \"rssi\": " + String(WiFi.RSSI()) + ", \"bridge_port\": " + String(BRIDGE_PORT) +
         ", \"client\": " + (clientConnected ? "\"" + clientAddress + "\"" : String("null")) + "}";
}

esp_err_t handleStatus(httpd_req_t *req) {
  String body = statusJson();
  httpd_resp_set_type(req, "application/json");
  httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");
  return httpd_resp_send(req, body.c_str(), body.length());
}

esp_err_t handleIndex(httpd_req_t *req) {
  String mode = visionFound ? "Grove Vision AI V2 gevonden (beeld + AI)" : ownCamera ? "Eigen camera van de XIAO (beeld, geen AI)" : "Geen camera gevonden";
  String page =
    "<!doctype html><meta charset=utf-8><meta name=viewport content='width=device-width'><title>Bittle camera</title>"
    "<style>body{font:16px system-ui;margin:24px;max-width:560px}td{padding:4px 12px 4px 0}button{font:inherit;padding:6px 12px}</style>"
    "<h1>Bittle camera</h1><table>"
    "<tr><td>Camera<td>" + mode +
    "<tr><td>Wifi<td>" + WiFi.SSID() + " (" + String(WiFi.RSSI()) + " dBm)"
    "<tr><td>Adres<td>" + WiFi.localIP().toString() + " &middot; " + NAME + ".local"
    "<tr><td>Platform<td>" + (clientConnected ? "verbonden vanaf " + clientAddress : String("niet verbonden")) +
    "<tr><td>Versie<td>" + VERSION + "</table>"
    "<p>Kies in het Bittle Platform bij de camera <b>Wifi-camera</b> met adres <b>" + NAME + ".local</b> (of " +
    WiFi.localIP().toString() + ").</p>" + (ownCamera ? "<p><img src=/frame.jpg style='max-width:100%'></p>" : "") +
    "<form method=post action=/forget onsubmit=\"return confirm('Wifi vergeten? De camera opent daarna weer de hotspot Bittle-Camera.')\">"
    "<button>Wifi vergeten</button></form>";
  httpd_resp_set_type(req, "text/html; charset=utf-8");
  return httpd_resp_send(req, page.c_str(), page.length());
}

esp_err_t handleFrame(httpd_req_t *req) {
  camera_fb_t *frame = ownCamera ? esp_camera_fb_get() : nullptr;
  if (!frame) {
    httpd_resp_send_err(req, HTTPD_404_NOT_FOUND, "Geen eigen camera");
    return ESP_FAIL;
  }
  httpd_resp_set_type(req, "image/jpeg");
  httpd_resp_set_hdr(req, "Access-Control-Allow-Origin", "*");
  esp_err_t result = httpd_resp_send(req, (const char *)frame->buf, frame->len);
  esp_camera_fb_return(frame);
  return result;
}

void forgetWifi() {
  WiFiManager manager;
  manager.resetSettings();
  delay(200);
  ESP.restart();
}

esp_err_t handleForget(httpd_req_t *req) {
  const char *page = "<!doctype html><meta charset=utf-8><p>Wifi vergeten. Verbind met de hotspot <b>Bittle-Camera</b> om een netwerk te kiezen.</p>";
  httpd_resp_set_type(req, "text/html; charset=utf-8");
  httpd_resp_send(req, page, strlen(page));
  delay(500);
  forgetWifi();
  return ESP_OK;
}

void startWeb() {
  httpd_config_t config = HTTPD_DEFAULT_CONFIG();
  config.server_port = 80;
  if (httpd_start(&web, &config) != ESP_OK) return;
  httpd_uri_t pages[] = {
    {"/", HTTP_GET, handleIndex, nullptr},
    {"/status", HTTP_GET, handleStatus, nullptr},
    {"/frame.jpg", HTTP_GET, handleFrame, nullptr},
    {"/forget", HTTP_POST, handleForget, nullptr},
  };
  for (auto &page : pages) httpd_register_uri_handler(web, &page);
}

// Holding BOOT for 5 s forgets the wifi network (for when it moves to another place).
void checkButton() {
  if (digitalRead(BOOT_BUTTON) == LOW) {
    if (!buttonDown) buttonDown = millis();
    if (millis() - buttonDown > FORGET_HOLD_MS) forgetWifi();
  } else {
    buttonDown = 0;
  }
}

// ---- Start and main loop ----

void setup() {
  Serial.begin(115200);
  pinMode(LED, OUTPUT);
  digitalWrite(LED, HIGH);
  pinMode(BOOT_BUTTON, INPUT_PULLUP);

  vision.setRxBufferSize(65536);
  vision.begin(VISION_BAUD, SERIAL_8N1, VISION_RX, VISION_TX);
  delay(1500);  // the Vision AI V2 boots with the XIAO when they share power
  visionFound = probeVision();
  ownCamera = startOwnCamera();
  Serial.printf("Vision AI V2: %s, eigen camera: %s\n", visionFound ? "ja" : "nee", ownCamera ? "ja" : "nee");

  WiFi.mode(WIFI_STA);
  WiFi.setHostname(NAME);
  WiFiManager manager;
  manager.setHostname(NAME);
  manager.setConnectTimeout(20);
  manager.setConfigPortalTimeout(300);  // no answer in the setup page for 5 minutes: start again and retry the network
  manager.setTitle("Bittle camera");
  if (!manager.autoConnect(HOTSPOT)) ESP.restart();
  WiFi.setSleep(false);  // full speed for the picture stream
  WiFi.setAutoReconnect(true);

  MDNS.begin(NAME);
  MDNS.addService("http", "tcp", 80);
  MDNS.addService("bittle-cam", "tcp", BRIDGE_PORT);
  startWeb();
  bridge.begin();
  bridge.setNoDelay(true);
  digitalWrite(LED, LOW);
  Serial.printf("Klaar: http://%s.local of http://%s\n", NAME, WiFi.localIP().toString().c_str());
}

void loop() {
  checkButton();
  digitalWrite(LED, WiFi.isConnected() ? LOW : HIGH);
  WiFiClient client = bridge.accept();
  if (!client) {
    delay(10);
    return;
  }
  client.setNoDelay(true);
  clientAddress = client.remoteIP().toString();
  clientConnected = true;
  visionFound = probeVision();  // ask again: the board may have started later, or been taken off
  if (visionFound) runBridge(client);
  else runOwnCamera(client);
  client.stop();
  clientConnected = false;
}
